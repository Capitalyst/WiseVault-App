class RouteNames {
  static String splash = 'splash';
  static String home = 'home';
  static String balance = 'balance';
  static String investment = 'investment';
  static String retirement = 'retirement';
  static String error = 'error';
}
