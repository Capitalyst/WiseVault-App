part of 'internet_cubit.dart';

@immutable
class InternetState {
  final bool isConnected;

  const InternetState({
    this.isConnected = false,
  });
}
