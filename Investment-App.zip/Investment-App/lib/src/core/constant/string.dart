class Config {
  static const String baseUrl =
      'https://t1tv04jr-8001.inc1.devtunnels.ms/api/user';
  static const String geminiAPI = "AIzaSyDlQsbxMHUiED9A81NT-s9a62hpJVT0g1k";
}
